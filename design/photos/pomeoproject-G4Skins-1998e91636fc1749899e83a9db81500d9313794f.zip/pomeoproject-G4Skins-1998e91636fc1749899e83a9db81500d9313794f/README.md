# pomeoproject
Project: Website Recreation - G4Skins
This project focuses on recreating websites, starting with G4Skins. It is a collaborative effort by three team members: Ponur, Janchol, and Matipapi.

Technologies Used
HTML
SCSS
JavaScript
CSS
Feel free to contribute or provide feedback as we continue to develop and refine this project!
